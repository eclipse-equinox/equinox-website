package org.eclipse.equinox.jsp.examples;

import javax.servlet.Servlet;
import org.eclipse.equinox.jsp.jasper.ContextPathServletAdaptor;
import org.eclipse.equinox.jsp.jasper.JspServlet;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.service.http.HttpContext;
import org.osgi.service.http.HttpService;
import org.osgi.util.tracker.ServiceTracker;

public class Activator implements BundleActivator {

	private ServiceTracker httpServiceTracker;

	public void start(BundleContext context) throws Exception {
		httpServiceTracker = new HttpServiceTracker(context);
		httpServiceTracker.open();
	}

	public void stop(BundleContext context) throws Exception {
		httpServiceTracker.open();
	}

	private class HttpServiceTracker extends ServiceTracker {

		public HttpServiceTracker(BundleContext context) {
			super(context, HttpService.class.getName(), null);
		}

		public Object addingService(ServiceReference reference) {
			final HttpService httpService = (HttpService) context.getService(reference);
			try {
				HttpContext commonContext = httpService.createDefaultHttpContext();
				httpService.registerResources("/jsp-examples", "/web", commonContext); //$NON-NLS-1$ //$NON-NLS-2$

				Servlet adaptedJspServlet = new ContextPathServletAdaptor(new JspServlet(context.getBundle(), "/web"), "/jsp-examples", "/web");  //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$
				httpService.registerServlet("/jsp-examples/*.jsp", adaptedJspServlet, null, commonContext); //$NON-NLS-1$
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return httpService;
		}

		public void removedService(ServiceReference reference, Object service) {
			final HttpService httpService = (HttpService) service;
			httpService.unregister("/jsp-examples"); //$NON-NLS-1$
			httpService.unregister("/jsp-examples/*.jsp"); //$NON-NLS-1$
			super.removedService(reference, service);
		}			
	}
}


