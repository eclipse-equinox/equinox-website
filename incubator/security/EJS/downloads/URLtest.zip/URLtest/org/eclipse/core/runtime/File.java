/*******************************************************************************
 * Copyright (c) 2000, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 * 
 * Generates URLs by using the org.eclipse.core.runtime.URL object 
 * which removes all security requirements except for:
 * 
 * permission java.io.FilePermission <target_file>, "read";
 * permission java.net.SocketPermission <host>:<port>,"connect";
 * permission org.eclipse.core.runtime.URLPermission "use";
 *
 *******************************************************************************/
package org.eclipse.core.runtime;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;

/**
 *
 * Created: Jan 11, 2005 9:00:23 AM
 * 
 */
public final class File extends java.io.File
{

  /**
   * @param uri
   */
  public File(URI uri)
  {
    super(uri);
    // TODO Auto-generated constructor stub
  }

  /**
   * @param parent
   * @param child
   */
  public File(String parent, String child)
  {
    super(parent, child);
    // TODO Auto-generated constructor stub
  }

  /**
   * @param pathname
   */
  public File(String pathname)
  {
    super(pathname);
    // TODO Auto-generated constructor stub
  }

  /**
   * @param parent
   * @param child
   */
  public File(java.io.File parent, String child)
  {
    super(parent, child);
    // TODO Auto-generated constructor stub
  }
  
  /**
   * @see java.io.File#toURL()
   */
  public URL toURL() throws MalformedURLException {
  	String absPath = getAbsolutePath();
  	if (File.separatorChar!='/') absPath.replace(File.separatorChar,'/');
  	if (absPath.getBytes()[0]!='/') absPath = "/" + absPath;
  	if (isDirectory() && absPath.endsWith("/")) absPath+="/"; 		
  	return new org.eclipse.core.runtime.URL("file", "",absPath).getURL();
      }

}
