/*
 * Created on Jan 10, 2005 by habeck
 *
 * (c) IBM Corporation 2005.  All Rights Reserved.
 */
package org.eclipse.core.runtime;

import java.security.BasicPermission;

/**
 * @author habeck
 *
 * Created: Jan 10, 2005 1:57:08 PM
 * 
 */
public class URLPermission extends BasicPermission
{
  /**
   * @param name
   * @param actions
   */
  public URLPermission(String name, String actions)
  {
    super(name, actions);
    // TODO Auto-generated constructor stub
  }

  /**
   * @param name
   */
  public URLPermission(String name)
  {
    super(name);
    // TODO Auto-generated constructor stub
  }
}
