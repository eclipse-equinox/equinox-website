/*******************************************************************************
 * Copyright (c) 2000, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation 
 * 
 * URL - A wrapper class for a java.net.URL object to reduce the 
 * privileges required to create one.  Class loading of specified 
 * protocol handlers is done under a privileged action.
 * 
 * All callers must be granted the following permission:
 * 
 * permission org.eclipse.core.runtime.URLPermission "use";
 * 
 * If the URL uses a socket based protocol, then the following permission is also required:
 * 
 * permission java.net.SocketPermission "connect";
 * 
 * If the URL referrs to a file, then the following permission is requird:
 * 
 * permission java.io.FilePermission "<file_name>","read";
 *
 *******************************************************************************/
package org.eclipse.core.runtime;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.SocketPermission;
import java.net.URLConnection;
import java.net.URLStreamHandler;
import java.net.URLStreamHandlerFactory;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;

/**
 * 
 * Created: Jan 10, 2005 1:50:35 PM
 *  
 */
public final class URL
{
  private java.net.URL url;

  /**
   * @see java.net.URL#URL(java.lang.String)
   * @throws MalformedURLException
   */
  public URL(String spec) throws MalformedURLException
  {
    this((java.net.URL)null, spec);
  }

  /**
   * @see java.net.URL#URL(java.lang.String, java.lang.String, int, java.lang.String)
   * @throws MalformedURLException
   */
  public URL(String protocol, String host, int port, String file)
      throws MalformedURLException
  {
    this(protocol, host, port, file, null);
  }

  /**
   * @see java.net.URL#URL(java.net.URL, java.lang.String) 
   * @throws MalformedURLException
   */
  public URL(URL context, String spec) throws MalformedURLException
  {
    this(context, spec, null);
  }
  
  /**
   * @see    java.net.URL#URL(java.net.URL, java.lang.String)
   * @throws MalformedURLException
   */
  public URL(final java.net.URL context, String spec) throws MalformedURLException
  {
  	this(context,spec,null);
  }

  /**
   * @see    java.net.URL#URL(java.net.URL, java.lang.String, java.net.URLStreamHandler) 
   * @throws MalformedURLException
   */
  public URL(final java.net.URL context,final String spec,final URLStreamHandler handler)
  		throws MalformedURLException
  {
    SecurityManager sm = System.getSecurityManager();
    if (sm!=null)
    { 
      java.net.URL tmpURL = null;
      sm.checkPermission(new URLPermission("use")); 
      try
      {
      	tmpURL = (java.net.URL) AccessController.doPrivileged(new PrivilegedExceptionAction(){

          public Object run() throws Exception
          {
            return new java.net.URL(context,spec,handler);
          }});
      } catch (PrivilegedActionException e)
      {
        throw (MalformedURLException) e.getException();
      }
      
      // Since we don't want to deal with parsing out the spec, build the URL and then check the permissions on it.
      String protocol = tmpURL.getProtocol();
      String file = tmpURL.getFile();
      String host = tmpURL.getFile();
      // throw a security exception if the caller does not have permission to access the specified URL.
      enforceProtocolPermission(protocol,file,host);
      url = tmpURL;
    } else  this.url = new java.net.URL(context,spec,handler);
    
  }
  
  /**
   * 
   * @param context - An org.eclipse.core.runtime.URL object
   * @see    java.net.URL#URL(java.net.URL, java.lang.String, java.net.URLStreamHandler)
   * @throws MalformedURLException
   */
  public URL(final URL context,final String spec,final URLStreamHandler handler)
      throws MalformedURLException
  {
    this(context.getURL(),spec,handler);
  }

  
  private void enforceProtocolPermission(final String protocol,final String file, final String host)
  {
  	SecurityManager sm = System.getSecurityManager();
    if (protocol.equalsIgnoreCase("file"))
        sm.checkPermission(new java.io.FilePermission(file,"read"));
      else 
      { // Throw a security exception if the caller does not have access to the specified host/port.
        if (host!=null && !host.equalsIgnoreCase(""))
          sm.checkPermission(new SocketPermission(host,"connect"));
        else
          sm.checkPermission(new SocketPermission("localhost","connect"));
      }
  }

  /**
   * @see    java.net.URL#URL(java.lang.String, java.lang.String, java.lang.String) 
   * @throws MalformedURLException
   */    
  public URL(String protocol, String host, String file)
      throws MalformedURLException
  {
    this(protocol, host, -1, file);
  }

  
  
  /**
   * @see    java.net.URL#URL(java.lang.String, java.lang.String, int, java.lang.String) 
   * @throws MalformedURLException
   */
  public URL(final String protocol, final String host,final int port,final String file,
      URLStreamHandler handler) throws MalformedURLException
  {
    // Perform permission checks
    SecurityManager sm = System.getSecurityManager();

    if (sm!=null)
    { // Throw a security exception if the caller does not have URLPermission.
      sm.checkPermission(new URLPermission("use"));
      // Throw a security exception if the caller does not have read permission
      // for the implied file.
      if (protocol!=null)
      { // Throw a security exception if the caller does not have the required permissions.
      	enforceProtocolPermission(protocol,file,host);
	    try
        {
	        this.url = (java.net.URL) AccessController.doPrivileged(new PrivilegedExceptionAction() {

            public Object run() throws MalformedURLException
            {
              java.net.URL newURL = new java.net.URL(protocol, host, port, file);
              return newURL;
            }});
        } catch (PrivilegedActionException e)
        {
          // only throws MalformedURLException
          throw (MalformedURLException) e.getException();
        }
 
      }
    } else  // Security is not enabled.  Just instanciate a URL as usual...
        this.url = new java.net.URL(protocol, host, port, file);
  }  
  
  public String getQuery()
  {
    return url.getQuery();
  }

  public String getPath()
  {
    return url.getPath();
  }

  public String getUserInfo()
  {
    return url.getUserInfo();
  }

  public String getAuthority()
  {
    return url.getAuthority();
  }

  public int getPort()
  {
    return url.getPort();
  }

  public int getDefaultPort()
  {
    return url.getDefaultPort();
  }

  public String getProtocol()
  {
    return url.getProtocol();
  }

  public String getHost()
  {
    return url.getHost();
  }

  public String getFile()
  {
    return url.getFile();
  }

  public String getRef()
  {
    return url.getRef();
  }

  public boolean equals(Object obj)
  {
    if (!(obj instanceof URL))
      return false;
    URL u2 = (URL) obj;
    return url.equals(u2.url);
  }

  public synchronized int hashCode()
  {
    return url.hashCode();
  }

  /**
   * @see    java.net.URL#sameFile(java.net.URL)
   * @return boolean
   */
  public boolean sameFile(URL other)
  {
    return url.sameFile(other.url);
  }

  /**
   * @see java.net.URL#toString()
   * @return String
   */
  public String toString()
  {
    return url.toString();
  }

  /**
   * @see		java.net.URL#toExternalForm()
   * @return String
   */
  public String toExternalForm()
  {
    return url.toExternalForm();
  }

  /**
   * @see    java.net.URL#openConnection()
   * @return java.net.URLConnection
   * @throws java.io.IOException
   */
  public URLConnection openConnection() throws java.io.IOException
  {
    return url.openConnection();
  }

  /**
   * @see    java.net.URL#openStream() 
   * @throws java.io.IOException
   */
  public final InputStream openStream() throws java.io.IOException
  {
    return openConnection().getInputStream();
  }

  /**
   * @see    java.net.URL#getContent()
   * @throws java.io.IOException
   */
  public final Object getContent() throws java.io.IOException
  {
    return openConnection().getContent();
  }

  /**
   * @see    java.net.URL#getContent(java.lang.Class[])
   * @throws java.io.IOException
   */
  public final Object getContent(Class[] classes) throws java.io.IOException
  {
    return openConnection().getContent(classes);
  }
  
  /** 
   * @see java.net.URL#setURLStreamHandlerFactory(java.net.URLStreamHandlerFactory)
   */
  public static void setURLStreamHandlerFactory(URLStreamHandlerFactory fac) {
    java.net.URL.setURLStreamHandlerFactory(fac);
  }  
  /**
   * @return Returns the url.
   */
  public final java.net.URL getURL()
  {
    return url;
  }
}