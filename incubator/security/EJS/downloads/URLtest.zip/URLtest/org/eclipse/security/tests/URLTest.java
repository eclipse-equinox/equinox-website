/*******************************************************************************
 * Copyright (c) 2000, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.security.tests;

import java.io.BufferedReader;
//import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
//import java.net.URL;
import org.eclipse.core.runtime.URL;
import org.eclipse.core.runtime.File;

/**
 * @author habeck
 *
 * Created: Jan 10, 2005 11:17:16 AM
 * 
 */
public class URLTest
{

  /**
   * 
   */
  public URLTest()
  {
    super();
    // TODO Auto-generated constructor stub
  }

  public static void main(String[] args)
  {
     // Demonstrate the permissions required to construct a URL.
    File myFile = new File("C:\\mytest.txt");
    try
    {
      // A file URL.
      URL myURL = new URL(myFile.toURL(),"file://c:/test.txt");
      // A network URL.
      URL netURL = new URL("http","archive.ncsa.uiuc.edu",80,"/SDG/Software/Mosaic/Demo/url-primer.html");
      URL anotherFile = new URL("file", "", "C:\\anothertest.txt");
      URL newURL = new URL("http","www.eclipse.org",80,"/");
      System.out.println(newURL.toString());
      try
      {
        InputStream is = newURL.openStream();
        InputStreamReader isr = new InputStreamReader(is);
        BufferedReader br = new BufferedReader(isr);
        String lineRead;
        while ((lineRead = br.readLine())!=null)
          System.out.println(lineRead);
      } catch (Exception e)
      {
        e.printStackTrace();
      }
    } catch (MalformedURLException e)
    {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    
  }
}
